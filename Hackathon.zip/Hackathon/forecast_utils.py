# forecast_utils.py

import pandas as pd
import numpy as np
from prophet import Prophet

def forecast_demand_for_part(df, part_name, periods=30):
    df = df[df["part_name"] == part_name].copy()
    df = df.groupby("date")["inventory_level"].sum().diff().dropna().reset_index()
    df.columns = ["ds", "y"]
    df["y"] = df["y"].abs()

    if len(df) < 10:
        return np.random.poisson(5, size=periods).tolist()

    model = Prophet()
    model.fit(df)
    future = model.make_future_dataframe(periods=periods)
    forecast = model.predict(future)
    return forecast["yhat"].tail(periods).clip(lower=0).tolist()
