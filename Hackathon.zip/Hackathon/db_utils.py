# db_utils.py
import pandas as pd
from sqlalchemy import create_engine, text
import psycopg2
from datetime import datetime

# 🔐 PostgreSQL Config - Replace with your credentials
DB_CONFIG = {
    "dbname": "Hackathon",
    "user": "postgres",
    "password": "apple",
    "host": "localhost",
    "port": 5432
}

# 🔗 SQLAlchemy engine string
DB_URI = f"postgresql+psycopg2://{DB_CONFIG['user']}:{DB_CONFIG['password']}@" \
         f"{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['dbname']}"

# Create SQLAlchemy engine
engine = create_engine(DB_URI)

# 📥 Fetch inventory data from DB for latest date only
def get_inventory():
    query = """
        SELECT DISTINCT ON (warehouse, part_name) 
            date, warehouse, part_name, inventory_level
        FROM public.warehouse_inventory_by_part
        ORDER BY warehouse, part_name, date DESC
    """
    df = pd.read_sql(query, engine)
    return df

def get_threshold(partname):
    query = text("""
        SELECT threshold_quantity
        FROM public.reorder_thresholds
        WHERE part_name = :partname
        LIMIT 1
    """)
    result = pd.read_sql(query, engine, params={"partname": partname})
    if not result.empty:
        return result.iloc[0]['threshold_quantity']
    else:
        return None

# ✍️ Add or update inventory record
def update_inventory(date, warehouse, part_name, inventory_level):
    # Keeping psycopg2 here because SQLAlchemy doesn't easily handle UPSERTs with WHERE clauses
    conn = psycopg2.connect(**DB_CONFIG)
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT sr FROM warehouse_inventory_by_part 
            WHERE date = %s AND warehouse = %s AND part_name = %s
        """, (date, warehouse, part_name))
        result = cursor.fetchone()

        if result:
            cursor.execute("""
                UPDATE warehouse_inventory_by_part
                SET inventory_level = %s
                WHERE sr = %s
            """, (inventory_level, result[0]))
        else:
            cursor.execute("""
                INSERT INTO warehouse_inventory_by_part (date, warehouse, part_name, inventory_level)
                VALUES (%s, %s, %s, %s)
            """, (date, warehouse, part_name, inventory_level))
    conn.commit()
    conn.close()
