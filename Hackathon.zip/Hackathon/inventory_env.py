import gym
from gym import spaces
import numpy as np

class InventoryManagementEnv(gym.Env):
    def __init__(self,
                 forecasted_demand=None,
                 selected_part=None,
                 initial_inventory=50,
                 max_inventory=100,
                 max_order_qty=50,
                 min_order_qty=10,
                 lead_time=2,
                 holding_cost=0.1,
                 shortage_cost=2.0,
                 order_cost=0.2,
                 no_order_penalty=2.0):

        super(InventoryManagementEnv, self).__init__()

        # Customizable parameters
        self.selected_part = selected_part
        self.initial_inventory = initial_inventory
        self.max_inventory = max_inventory
        self.max_order_qty = max_order_qty
        self.min_order_qty = min_order_qty
        self.lead_time = lead_time

        self.holding_cost = holding_cost
        self.shortage_cost = shortage_cost
        self.order_cost = order_cost
        self.no_order_penalty = no_order_penalty

        # Demand forecast (can be passed externally)
        self.demand_forecast = forecasted_demand if forecasted_demand is not None else np.random.randint(10, 30, size=30)

        # Observation space: [inventory, next_demand, orders_in_transit]
        self.observation_space = spaces.Box(
            low=0,
            high=np.array([self.max_inventory, 1000, self.max_order_qty * self.lead_time]),
            dtype=np.float32
        )

        # Action space: multiples of min_order_qty (e.g., 0, 10, 20, ..., 50)
        self.action_space = spaces.Discrete((self.max_order_qty // self.min_order_qty) + 1)

        self.reset()

    def reset(self):
        self.current_step = 0
        self.inventory = self.initial_inventory
        self.order_queue = [0] * self.lead_time
        return self._get_obs()

    def _get_obs(self):
        next_demand = self.demand_forecast[self.current_step] if self.current_step < len(self.demand_forecast) else 0
        in_transit = sum(self.order_queue)
        return np.array([self.inventory, next_demand, in_transit], dtype=np.float32)

    def step(self, action):
        # Convert action to order quantity
        order_qty = action * self.min_order_qty if action > 0 else 0
        order_qty = min(order_qty, self.max_order_qty)

        # Receive arrived order
        arrived_order = self.order_queue.pop(0)
        self.inventory = min(self.inventory + arrived_order, self.max_inventory)

        # Place new order
        self.order_queue.append(order_qty)

        # Demand for current step
        demand = self.demand_forecast[self.current_step]
        unmet_demand = max(0, demand - self.inventory)
        self.inventory = max(0, self.inventory - demand)

        # Cost components
        holding_cost = self.inventory * self.holding_cost
        shortage_cost = unmet_demand * self.shortage_cost
        order_cost = order_qty * self.order_cost
        no_order_penalty = self.no_order_penalty if (self.inventory < demand and order_qty == 0) else 0.0

        total_cost = holding_cost + shortage_cost + order_cost + no_order_penalty
        reward = -total_cost

        # Advance to next step
        self.current_step += 1
        done = self.current_step >= len(self.demand_forecast)

        return self._get_obs(), reward, done, {}

    def render(self, mode='human'):
        print(f"Step: {self.current_step}, Inventory: {self.inventory}, Orders in Transit: {self.order_queue}")
