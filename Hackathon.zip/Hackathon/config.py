# config.py
DB_CONFIG = {
    "dbname": "Hackathon",
    "user": "postgres",
    "password": "apple",
    "host": "localhost",
    "port": 5432
}
