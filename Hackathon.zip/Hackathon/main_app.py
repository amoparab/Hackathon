import streamlit as st
from streamlit_autorefresh import st_autorefresh
from datetime import datetime
import pandas as pd

from db_utils import get_inventory, get_threshold, update_inventory
from forecast_utils import forecast_demand_for_part
from inventory_env import InventoryManagementEnv

# 🚀 Page config
st.set_page_config(page_title="🧠 AI-Powered Supply Chain Dashboard", layout="wide")
st.title("🧠 AI-Powered Multi-Agent Supply Chain System")

# 📚 Tabs
tabs = st.tabs([
    "📦 Inventory Optimization Agent",
    "📈 Demand Prediction Agent",
    "🚛 Supplier & Logistics Agent",
    "🌍 Geopolitical Risk Agent"
])

# ========== INVENTORY OPTIMIZATION AGENT ==========
with tabs[0]:
    st.header("📦 Inventory Optimization Agent")
    sub_tabs = st.tabs(["📋 View & Update Inventory", "➖ Reduce Inventory"])

    # === View & Update Inventory ===
    with sub_tabs[0]:
        st_autorefresh(interval=300_000, key="data_refresh")
        df = get_inventory()

        if df.empty:
            st.info("No inventory data found.")
        else:
            st.subheader("🔎 Filter Inventory Data")
            col1, col2 = st.columns([1, 1])
            with col1:
                selected_warehouse = st.selectbox("🏭 Select Warehouse", options=["All"] + sorted(df["warehouse"].unique()))
            with col2:
                selected_part = st.selectbox("🔧 Select Part Name", options=["All"] + sorted(df["part_name"].unique()))

            if selected_warehouse == "All" and selected_part == "All":
                filtered_df = df.copy()
            elif selected_warehouse != "All" and selected_part == "All":
                filtered_df = df[df["warehouse"] == selected_warehouse].copy()
            elif selected_warehouse == "All" and selected_part != "All":
                filtered_df = df[df["part_name"] == selected_part].copy()
            else:
                filtered_df = df[
                    (df["warehouse"] == selected_warehouse) &
                    (df["part_name"] == selected_part)
                ].copy()

            st.subheader("📋 Inventory for Latest Date")
            st.dataframe(filtered_df, use_container_width=True)

            LOW_STOCK_THRESHOLD = 50
            low_stock_df = filtered_df[filtered_df["inventory_level"] < LOW_STOCK_THRESHOLD]
            if not low_stock_df.empty:
                st.warning("⚠️ Low stock parts detected!")
                st.table(low_stock_df)

            st.subheader("✍️ Add / Update Inventory Record")
            with st.form("update_inventory_form"):
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    part_name = st.text_input("Part Name")
                with col2:
                    warehouse = st.text_input("Warehouse")
                with col3:
                    inventory_level = st.number_input("Inventory Level", min_value=0.0, step=1.0)
                with col4:
                    date = st.date_input("Date", datetime.now().date())

                submitted = st.form_submit_button("💾 Save Record")
                if submitted:
                    if not part_name or not warehouse:
                        st.error("Part Name and Warehouse are required.")
                    else:
                        update_inventory(date, warehouse, part_name, inventory_level)
                        st.success(f"✅ Inventory updated for '{part_name}' at '{warehouse}'.")
                        st.experimental_rerun()

    # === Reduce Inventory and Optimize ===
    with sub_tabs[1]:
        st.subheader("➖ Reduce Inventory")
        df = get_inventory()
        if df.empty:
            st.info("No inventory data found.")
        else:
            warehouses = sorted(df["warehouse"].unique())
            parts = sorted(df["part_name"].unique())

            col1, col2 = st.columns(2)
            with col1:
                selected_warehouse = st.selectbox("🏭 Select Warehouse", warehouses, key="reduce_warehouse")
            with col2:
                selected_part = st.selectbox("🔧 Select Part", parts, key="reduce_part")

            current_level = df[
                (df["warehouse"] == selected_warehouse) & (df["part_name"] == selected_part)
            ]["inventory_level"].values

            if current_level.size > 0:
                st.info(f"📦 Current Inventory: {current_level[0]} units")
                tre = get_threshold(selected_part)
                st.info(f"📦 Threshold Level: {tre} units")

                reduction = st.number_input("➖ Amount to Reduce", min_value=0.0, step=1.0)

                if st.button("✅ Reduce Inventory"):
                    new_level = float(max(0, current_level[0] - reduction))
                    today = datetime.now().date()
                    update_inventory(today, selected_warehouse, selected_part, new_level)
                    st.success(f"✅ Reduced inventory of '{selected_part}' in '{selected_warehouse}' to {new_level}")
                    st.rerun()
            else:
                st.warning("No inventory record found for selected warehouse and part.")

            st.subheader("🧠 Connect to Inventory Optimization AI Agent")
            if st.button("📤 Send Inventory Snapshot to AI Agent"):
                if selected_part == "All":
                    st.warning("Please select a specific Part Name.")
                else:
                    st.info("🧠 Forecasting demand & optimizing inventory...")

                    part_df = df[df["part_name"] == selected_part]
                    if selected_warehouse != "All":
                        part_df = part_df[part_df["warehouse"] == selected_warehouse]

                    if part_df.empty:
                        st.error("No inventory data found for selected filters.")
                    else:
                        current_inventory = part_df["inventory_level"].sum()
                        st.write(f"📦 Current inventory for '{selected_part}': {current_inventory} units")

                        forecasted_demand = forecast_demand_for_part(df, selected_part, periods=30)
                        st.line_chart(pd.DataFrame(forecasted_demand, columns=["Forecasted Demand"]))
                        # Get Supplier constraint
                        env = InventoryManagementEnv(forecasted_demand, selected_part, initial_inventory=current_inventory)

                        best_action = None
                        best_reward = float('-inf')

                        for restock_amount in range(0, get_threshold(selected_part)):
                            env.reset()
                            total_reward = 0
                            done = False
                            obs, reward, done, _ = env.step(restock_amount)
                            total_reward += reward

                            while not done:
                                obs, reward, done, _ = env.step(0)
                                total_reward += reward

                            if total_reward > best_reward:
                                best_reward = total_reward
                                best_action = restock_amount

                        st.success(f"✅ AI Suggests Reordering **{best_action} units** of '{selected_part}'")

                        if st.checkbox("📝 Apply reorder now"):
                            today = datetime.now().date()
                            for _, row in part_df.iterrows():
                                new_level = row["inventory_level"] + best_action
                                update_inventory(today, row["warehouse"], row["part_name"], new_level)
                            st.success("📦 Inventory updated with reorder quantity.")
                            st.rerun()

# Placeholder tabs
with tabs[1]:
    st.header("📈 Demand Prediction Agent")
    st.markdown("Coming soon...")

with tabs[2]:
    st.header("🚛 Supplier & Logistics Agent")
    st.markdown("Coming soon...")

with tabs[3]:
    st.header("🌍 Geopolitical Risk Agent")
    st.markdown("Coming soon...")
